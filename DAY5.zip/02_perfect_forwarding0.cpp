﻿#include <iostream>

void foo(int& a)		{ std::cout << "int&" << std::endl; }
void foo(int&& a)		{ std::cout << "int&&" << std::endl; }

int main()
{
	int n = 10;
	foo(n);		// int&
	foo(10);	// int&&

	int& r1 = n;
	foo(r1);	// ?


	int&& r2 = 10;
	foo(r2);	// ?
}

// Point pt{1,1};
// "타입과 value category(lvalue, rvalue) 를 잘 구별하세요"
//					type		value category
// n				
// 10
// pt			
// Point{1,1}
// r1
// r2





