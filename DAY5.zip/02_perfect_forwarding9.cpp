﻿#include <iostream>
#include <vector>

class Point
{
	int x, y;
public:
	Point(int a, int b)	{ std::cout << "Point()" << std::endl;	}
	~Point()            { std::cout << "~Point()" << std::endl; }
	Point(const Point&) { std::cout << "copy ctor" << std::endl; }
	Point(Point&&)      { std::cout << "move ctor" << std::endl; }
};

int main()
{
	std::vector<Point> v;
	
	// vector에 요소 넣는 방법 
	
	// #1. 객체를 생성후 push_back 으로전달. 
	Point pt{1, 2};		
	v.push_back(pt);

	


	std::cout << "-----" << std::endl;
}

