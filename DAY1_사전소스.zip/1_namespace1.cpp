﻿// 2_namespace.cpp - 교재 7 page
#include <stdio.h>

void init() { printf("Audio init\n");	}
void init()	{ printf("Video init\n");	}

int main()
{
	init();
}
