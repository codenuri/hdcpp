// 6_cout - 187(136)page
#include <iostream>

// cout �� ����
int main()
{
	int    n = 10;
	double d = 3.4;

	std::cout << n;
	std::cout << d;
	
}


