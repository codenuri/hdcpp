#include "monitor.h"

class Monitor 
{
	int brightness = 80;
	int resolution = 1024;
public:
	void set_brightness(int value) { brightness = value; }
	int  get_brightness() const    { return brightness; }

	void set_resolution(int value) { resolution = value; }
	int  get_resolution() const    { return resolution; }
};

int main()
{
	Monitor m;
	
	// 모니터의 밝기를 변경하고 싶다.
	m.set_brightness(90);
}