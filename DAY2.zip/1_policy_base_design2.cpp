#include <iostream>

// 방법 #1. 변하는 것을 가상함수로 분리

template<typename T>
class vector
{
	T* ptr;
public:
	void resize(int n)
	{
		ptr = allocate(n);	// 메모리 할당이 필요하면 가상함수 호출
		deallocate(ptr, n);	// 메모리 메모리 해지도 가상함수 호출
	}
	virtual T* allocate(std::size_t sz) { return new T[sz];}
	virtual void deallocate(T* p, std::size_t sz) { delete[] p;}
};

// 의도 메모리 할당 방식을 변경하려면 약속된 가상함수를 override 
template<typename T> 
class malloc_vector : public vector<T>
{
public:
	T* allocate(std::size_t sz) override 
	{	
		void* p = malloc(sizeof(T)* sz);
		return static_cast<T*>(p);
	}
	void deallocate(T* p, std::size_t sz) override 
	{ 
		free(p);
	}
};

int main()
{
	
}