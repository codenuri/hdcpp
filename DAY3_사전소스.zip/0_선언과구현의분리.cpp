#include <iostream>


template<typename T>
class vector
{
	T* ptr;
	int  sz;
public:
	vector(int n, T value = 0)
	{
		sz = n;
		ptr = new T[sz];

		for (int i = 0; i < sz; i++)
		{
			ptr[i] = value;
		}
	}
	~vector() { delete[] ptr; }

	T& at(int idx) { return ptr[idx]; }


	void resize(int newsize)
	{
		if (newsize > sz)
		{
			T* tmp = new T[newsize];

			memcpy(tmp, ptr, sizeof(T) * sz);

			delete[] ptr;

			ptr = tmp;

			sz = newsize;
		}
		else
		{
		}
	}

	int size() { return sz; }
	bool empty() { return sz == 0; }
};



int main()
{
	vector<int>    v1(5, 3);
	vector<double> v2(5, 3.1);

	v1.at(0) = 10;
	v1.resize(10);
	
	std::cout << v1.at(0) << std::endl;
	std::cout << v1.size() << std::endl;

}