// Test 용 함수들

void foo()       { std::cout << "foo\n"; _getch(); }
void goo(int id) { std::cout << "goo : " << id << '\n'; _getch(); }

class Car
{
public:
	void start_record(int resolution) 
	{
		std::cout << "녹화시작. 해상도 : " << resolution << '\n';
		_getch();
	}
	void end_record()
	{
		std::cout << "녹화종료 \n";
		_getch();
	}
};
