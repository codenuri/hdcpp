#include <iostream>
#include <vector>
#include <string>

class File  
{
public:
};
class Folder 
{
public:
};


// [복습하실때]
// 아래 main 함수가 실행될수 있도록 File, Folder 만들어 보세요

// Folder 는 File을 보관하지만 Folder 자신도 보관합니다.
// => PopupMenu/MenuItem 관계와 동일합니다
// => composite 패턴의 전형적인 예입니다.

int main()
{
	Folder* root = new Folder("ROOT");
	Folder* fo1  = new Folder("A");
	Folder* fo2  = new Folder("B");
	
	root->add(fo1);
	root->add(fo2);

	File* f1 = new File("a.txt", 10);
	File* f2 = new File("b.txt", 20);

	fo1->add(f1);
	root->add(f2);

	// File   은 자신만의 크기를 가지지만
	// Folder 는 자신의 크기는 없습니다. 하지만 크기를 구할수는 있습니다
	std::cout << f2->get_size() << std::endl; // 20		// 파일 크기
	std::cout << fo1->get_size() << std::endl; // 10	// 폴더 크기
	std::cout << root->get_size() << std::endl; // 30	// 폴더 크기
}

