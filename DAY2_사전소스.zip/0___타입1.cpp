int main()
{
	bool b1 = false;
	bool b2 = true;

	long long n1 = 0;

}