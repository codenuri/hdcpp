﻿#include <iostream>


void foo(int n)    { std::cout << "int" << std::endl; }
void foo(double d) { std::cout << "double" << std::endl; }
void foo(bool b)   { std::cout << "bool" << std::endl; }
void foo(int* p)   { std::cout << "int*" << std::endl; }

int main()
{
	foo(0);
	
}
