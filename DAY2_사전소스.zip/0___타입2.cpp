#include <iostream>
#include <cstring>   // C ���ڿ� �Լ�
#include <string>    // C++ string Ÿ��

// 26 page

int main()
{
	char s1[] = "ABCD";
	char s2[5];

	s2 = s1;

	if (s2 == s1) {}
}