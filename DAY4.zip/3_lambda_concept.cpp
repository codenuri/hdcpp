int add(int a, int b) { return a + b;}

void foo( int(*)(int, int) )
{

}

int main()
{
	foo( &add );
}