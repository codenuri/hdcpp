#include <iostream>

class Point
{	
public:
	int x, y;
	Point(int a, int b) x:{a}, y{b} {}	
};

int main()
{
	Point pt{1,1};

	// reference 규칙
	Point& r1 = pt;
	Point& r2 = Point{1, 1};

	const Point& r3 = pt;
	const Point& r4 = Point{1, 1};


}







