﻿#include <iostream>

class Point
{	
public:
	int x, y;
	Point(int a, int b) x:{a}, y{b} {}	
};

int main()
{
	Point pt(1, 1);

	// #1. 임시객체 특징
	pt.x = 10;
	Point{1, 1}.x = 10;

	// #2. 용어
	// lvalue : 등호의 왼쪽에 올수 있는 표현식
	//			이름이 있다.
	// rvalue : 등호의 왼쪽에 올수 없는 표현식
	//			이름이 없다.
	int n = 3;
	n = 20;
	3 = 20;

	// reference 규칙
	Point& r1 = Point{1, 1};
	Point& r2 = Point{1, 1};
	const Point& r3 = Point{1, 1};
}







