class Animal { };
class Dog : Animal { };
class Cat : Animal { };

class Program
{
	// 1. 동종을 처리하는 함수
	// => 모든 Animal의 파생 클래스를 인자로 전달 받을수 있습니다.
	public static void TakeCareOf(Animal a)
	{

	}
    public static void Main()
    {
		Dog d = new Dog();
		Cat c = new Cat();
		TakeCareOf(d);
		TakeCareOf(c);

		// 2. 동종을 저장하는 클래스 
		// => 모든 Animal의 파생 클래스를 담을 수 있습니다.
		List<Animal> st = new List<Animal>();
		st.Add(d);
		st.Add(c);
    }
}

