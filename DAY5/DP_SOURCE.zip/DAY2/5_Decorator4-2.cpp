#include <iostream>
#include <string>

struct Component
{
	virtual void draw() = 0;
	virtual ~Component() {}
};

class Picture : public Component
{
	std::string url;
public:
	Picture(const std::string& url) : url(url) {}

	void draw() { std::cout << "draw " << url << std::endl; }
};

// ��� ��� �߰� Ŭ����(Decorator) �� ������ Ư¡�� ������ �ֽ��ϴ�.
// ��� Ŭ������ ���� ������ Ư¡�� �����մϴ�.

class Decorator : public Component
{
	Component* pic;
public:
	Decorator(Component* pic) : pic(pic) {}

	void draw() { pic->draw(); }
};

class DrawFrame : public Decorator
{	
public:
	DrawFrame(Component* pic) : Decorator(pic) {}

	void draw()
	{
		std::cout << "==================\n";
		Decorator::draw();
		std::cout << "==================\n";
	}
};

class DrawEmoticon : public Decorator
{	
public:
	DrawEmoticon(Component* pic) : Decorator(pic) {}

	void draw()
	{
		std::cout << "=======~*~=======\n";
		Decorator::draw();
		std::cout << "=======~*~========\n";
	}
};

int main()
{
	Picture pic("www.naver.com/a.png");
	pic.draw();

	DrawFrame frame(&pic);
	frame.draw();

	DrawEmoticon emoticon(&frame);
	emoticon.draw();
}
