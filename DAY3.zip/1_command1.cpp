#include "monitor.h"


int main()
{
	Monitor m;

	// 모니터의 밝기를 변경하고 싶다.
	m.set_brightness(90);
}