﻿#include <iostream>

// 싱글톤 : 오직 한개의 객체만 존재 하고, 
// 		   어디에서도 동일한 방법으로 접근 가능한 객체

class Cursor
{
};


int main()
{
	Cursor c1, c2;
}








